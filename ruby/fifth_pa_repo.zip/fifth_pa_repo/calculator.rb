







=begin
Handle invalid inputs by printing invalid input messages and retrying
Handle invalid calculations by printing an error when calculation could not be performed



=end














=begin
After the user user enters 'done' && before the program exits:
Print a count of the number of the calculations performed
Print the history of all the calculations performed

Ex: 
3 calculations performed:
4 + 5 = 9
3 - 1 = 2
8 / 2 = 4
(Hint: this program should involve a data structure)
=end


def calculation()

puts "Type done to exit: "
int_result = gets.chomp!

count = 0
while int_result != "done"

p "Enter a calculation you would like to perform: "
int_result = gets.chomp.delete(' ').chars
int_result.join(' ').delete(' ').delete(' , ')
int_result[0] = int_result[0].to_i
int_result[1] = int_result[1].to_sym
int_result[2] = int_result[2].to_i
p int_result = int_result[0].send(int_result[1], int_result[2])



puts "Type done to exit: "
int_result = gets.chomp!
count += 1

if int_result == 'done'
  p count
end 

end

end



calculation()












=begin
p "Enter a calculation you would like to perform: "
ex: user types "4 + 5" then the program prints "9" 
if long as the user does not enter 'done', then repeat above the 2 lines above^ 
if the user does enter 'done', then the program exits



def calculation()

puts "Type done to exit: "
input = gets.chomp!
while input != "done"

p "Enter a calculation you would like to perform: "
int_result = gets.chomp.delete(' ').chars
int_result.join(' ').delete(' ').delete(' , ')
int_result[0] = int_result[0].to_i
int_result[1] = int_result[1].to_sym
int_result[2] = int_result[2].to_i
p int_result[0].send(int_result[1], int_result[2])

puts "Type done to exit: "
input = gets.chomp!
end 

end

calculation()




=end







































#Method takes 3 parameters
  #an integer
  #the following operator strings: "+", "-", "*", and "/""
  #another integer
#Method uses the 3 parameters to perform operation & return the integer result
#Example of an operation & its integer result: calculate(4, '+', 5) = 9

=begin
def calculate()
p "Enter the first integer: "
int_1 = gets.chomp
p "Enter the operator: "
oper = gets.chomp
p "Enter the second integer: "
int_2 = gets.chomp

p int_result = int_1.to_i.send(oper.to_sym, int_2.to_i)

end

calculate()
=end



